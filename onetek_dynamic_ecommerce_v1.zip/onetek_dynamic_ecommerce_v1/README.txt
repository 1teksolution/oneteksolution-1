ONE TEK SOLUTION - Dynamic E-Commerce V1
Upload all files to GitHub repository root.
Main file: index.html
Product catalogue: products.html
Product data: products.json
Images: assets/images/
This version includes dynamic frontend search/filter/RFQ basket.
For full real e-commerce, next step requires backend/admin panel/database/payment gateway.
