
let products=[], current='All', cart=[];
const $=s=>document.querySelector(s);
const grid=$('#productGrid'), search=$('#searchBox');
async function init(){
  products = await fetch('products.json').then(r=>r.json());
  render(products); renderFilters(); updateCart();
}
function renderFilters(){
  const cats=['All','Manufacturing','Trading','Automotive Electronics','Fire & Safety Systems','Railway Electronics','Semiconductor Components','Electronic Components','RF Components'];
  $('#filters').innerHTML=cats.map(c=>`<button class="filter ${c==='All'?'active':''}" onclick="setFilter('${c}',this)">${c}</button>`).join('');
}
function setFilter(c,btn){current=c;document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));btn.classList.add('active');apply();}
function apply(){
  const q=(search?.value||'').toLowerCase();
  const list=products.filter(p=>(current==='All'||p.category===current||p.segment===current) && (p.name+p.id+p.segment+p.specs).toLowerCase().includes(q));
  render(list);
}
function render(list){
  grid.innerHTML=list.map(p=>`
  <article class="card">
    <img src="assets/images/${p.image}" onerror="this.src='assets/images/logo.png'" alt="${p.name}">
    <div class="card-body">
      <div class="tag">${p.category} • ${p.segment}</div>
      <h3>${p.name}</h3>
      <p>${p.specs}</p>
      <div class="row">
        <button class="smallbtn" onclick="openProduct('${p.id}')">View Details</button>
        <button class="smallbtn" onclick="addToCart('${p.id}')">Add RFQ</button>
      </div>
    </div>
  </article>`).join('');
}
function openProduct(id){
  const p=products.find(x=>x.id===id);
  $('#modalContent').innerHTML=`
  <button class="close" onclick="closeModal()">Close</button>
  <div class="modalgrid">
    <img src="assets/images/${p.image}" onerror="this.src='assets/images/logo.png'">
    <div>
      <div class="tag">${p.id} • ${p.category}</div>
      <h2>${p.name}</h2>
      <p style="color:#9fb0c5">${p.specs}</p>
      <h3>Key Features</h3>
      <ul>${p.features.map(f=>`<li>${f}</li>`).join('')}</ul>
      <button class="btn" onclick="addToCart('${p.id}')">Add to RFQ Basket</button>
      <a class="btn ghost" style="display:inline-block;margin-left:8px" target="_blank" href="https://wa.me/918505807245?text=I%20need%20quotation%20for%20${encodeURIComponent(p.name)}">WhatsApp Inquiry</a>
    </div>
  </div>`;
  $('#modal').classList.add('open');
}
function closeModal(){ $('#modal').classList.remove('open');}
function addToCart(id){ if(!cart.includes(id)) cart.push(id); localStorage.setItem('rfqCart',JSON.stringify(cart)); updateCart();}
function updateCart(){ cart=JSON.parse(localStorage.getItem('rfqCart')||'[]'); $('#cartBtn').textContent=`RFQ Basket (${cart.length})`; }
function openCart(){
  const items=cart.map(id=>products.find(p=>p.id===id)).filter(Boolean);
  const msg=items.map(p=>`${p.id} - ${p.name}`).join('%0A');
  if(!items.length){alert('RFQ basket is empty');return}
  window.open(`https://wa.me/918505807245?text=Hello%20One%20Tek%20Solution,%20please%20send%20quotation%20for:%0A${msg}`,'_blank');
}
document.addEventListener('input',e=>{if(e.target.id==='searchBox')apply()});
init();
